module.exports = {
    url: "mongodb+srv://amritconestoga9:amritsingh@cluster0.c3coz7g.mongodb.net/?retryWrites=true&w=majority&appName=Cluster0"
}